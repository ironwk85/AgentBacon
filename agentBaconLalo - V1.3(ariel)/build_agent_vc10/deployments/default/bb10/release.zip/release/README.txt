This folder contains an application deployed using the Marmalade SDK.

    Application : AgentBacon
        Version : 4.0
    SDK Version : 6.2.0BETA [332698]
  Date Deployed : Sun Mar 24 23:11:06 2013
      Target OS : bb10 (Blackberry 10 QNX (beta))
  Configuration : Release
